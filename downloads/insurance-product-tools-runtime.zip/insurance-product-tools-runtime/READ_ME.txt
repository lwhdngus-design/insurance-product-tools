﻿Insurance Product Tools 실행용 배포 구성

개발·시험·게시 도구, 공시실 다운로드 도구, 분할압축 도구는 제외했습니다.
Python 소스는 serve.py와 word_docs.py 2개이며 본래 확장자로 포함됩니다.
Windows Word 미리보기에는 word-preview.ps1도 사용합니다.
기능에 필요한 .js·.html·로컬 라이브러리·데이터와 교육용 가상 PDF는 유지합니다.
main-logic.txt는 기존 교육 화면의 소스 참조 문서이며 실행하지 않습니다.
전체 파일명·확장자·용도·해시는 FILES.csv에서 확인할 수 있습니다.

반입·실행:
회사 정책이 .py를 차단하면 이 배포본도 승인된 경로/형식이 확인되기 전에는 반입할 수 없습니다.
회사 IT에 Python 소스 2개, .ps1 및 실행 파일의 반입·실행 허용 여부를 확인하세요.
현재 반입 정책에 맞춰 승인된 설치/배포 방식이 정해지면 그 규격으로 배포해야 합니다.

회사에서 허용한 배포 경로로 설치한 후 Python 3.9 이상으로 start-search.bat을 실행합니다.
새 배포본은 별도 폴더에 풀고 기존 Word·PDF 원본 폴더를 연결하세요.
기존 문서·docs-folder.txt·.docs-cache는 그대로 보존하세요.
Python 설치파일은 포함하지 않습니다.
Word 그림 보기는 Windows Microsoft Word 또는 LibreOffice가 필요합니다.
실제 회사 문서, 다운로드 기록, 계정정보는 포함하지 않습니다.
