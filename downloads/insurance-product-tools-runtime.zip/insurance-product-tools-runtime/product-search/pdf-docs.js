// 기초서류 PDF 폴더 연결 — 선택한 폴더의 PDF 본문을 브라우저(PC) 안에서 읽어 검색에 포함
// 파일은 업로드·저장하지 않고 메모리에만 둡니다. (index.html의 norm, esc, $, readForm, TODAY 사용)

// ---------- pdf.js 설정: 서버 없이(file://) 동작하도록 내장 한글 CMap 사용 ----------
class EmbeddedCMapReaderFactory {
  constructor() {}
  async fetch({ name }) {
    const b64 = window.PDF_CMAPS_KO && window.PDF_CMAPS_KO[name];
    if (!b64) throw new Error(`CMap 없음: ${name}`);
    const bin = atob(b64);
    const data = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) data[i] = bin.charCodeAt(i);
    return { cMapData: data, compressionType: 1 }; // 1 = BINARY(bcmap)
  }
}

const DOCS = []; // { file, path, name, docType, productName, productKey, start, end, pages: [text], error }

// ---------- 경로·파일명 해석 ----------
const DOC_TYPES = ["요율확인의뢰서", "사업방법서", "산출방법서", "상품요약서", "약관"];
const docTypeOf = name => DOC_TYPES.find(t => name.includes(t)) || "기타";
const LINK_DOC_TYPES = ["산출방법서", "요율확인의뢰서"];
const isLinkOnly = d => LINK_DOC_TYPES.includes(d.docType);
const isWord = d => /\.(docx?|hwpx?)$/i.test(d.name);
const docLoc = (d, page) => d.textKind === "section" ? `구간 ${page}` : `p.${page}`;
const refAttrs = (d, page, anchor = "") => `data-open="${DOCS.indexOf(d)}" data-page="${page}" data-unit="${d.textKind === "section" ? "section" : "page"}"${anchor && d.textKind === "section" ? ` data-anchor="${esc(anchor.slice(0, 600))}"` : ""}`;

const pad = n => String(n).padStart(2, "0");
function validDate(y, m, d) {
  y = +y; m = +m; d = +(d || 1);
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  return `${y}-${pad(m)}-${pad(d)}`;
}

// 문자열에서 날짜를 모두 찾기: 2023.01.01 / 2023-1-1 / 2023년 1월 1일 / 20230101 / 230101 / 2023.01 / 202301
function findDates(str) {
  const found = [];
  const patterns = [
    [/(?<!\d)((?:19|20)\d{2})\s*[.\-_/년]\s*(\d{1,2})\s*(?:[.\-_/월]\s*(\d{1,2})\s*일?)?(?!\d)/g, m => validDate(m[1], m[2], m[3]), m => !!m[3]],
    [/(?<!\d)((?:19|20)\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])(?!\d)/g, m => validDate(m[1], m[2], m[3]), () => true],
    [/(?<!\d)(\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])(?!\d)/g, m => validDate("20" + m[1], m[2], m[3]), () => true],
    [/(?<!\d)((?:19|20)\d{2})(0[1-9]|1[0-2])(?!\d)/g, m => validDate(m[1], m[2]), () => false],
  ];
  for (const [re, toDate, hasDay] of patterns) {
    for (const m of str.matchAll(re)) {
      const date = toDate(m);
      const s = m.index, e = m.index + m[0].length;
      if (date && !found.some(f => s < f.e && e > f.s)) found.push({ s, e, date, text: m[0], hasDay: hasDay(m) });
    }
  }
  return found.sort((a, b) => a.s - b.s);
}

// 판매일자: 가장 안쪽 폴더명부터 찾고, 없으면 파일명에서 찾음. 한 이름에 날짜가 2개면 시작~종료로 봄
// 판매여부 폴더: 경로의 폴더 이름에 "판매중지·판매종료·판매중단·중지상품"이 있으면 판매중지, "판매중·판매상품"이 있으면 판매중
// 예) 판매중/2026/2026.04.01/(무)OO보험/…pdf, 판매중지상품/2014/…  (파일명은 보지 않음)
function saleFolderOf(path) {
  const folders = path.split("/").slice(0, -1).map(norm);
  if (folders.some(f => /판매중지|판매종료|판매중단|중지상품|판매안함/.test(f))) return "stop";
  if (folders.some(f => /판매중|판매상품|현재판매/.test(f))) return "on";
  return "";
}

// 문서의 판매상태: 판매여부 폴더가 있으면 그 기준, 없으면 판매일자로 추정
// (판매중 폴더라도 같은 상품의 더 최근 판매일자가 있으면 이전 판매일자는 판매종료)
function docSaleStatus(d) {
  if (d.saleFolder === "stop") return "판매종료";
  if (!d.start) return d.saleFolder === "on" ? "판매중" : "미상";
  if (d.start > TODAY) return "판매예정";
  return !d.end || d.end >= TODAY ? "판매중" : "판매종료";
}

function saleDatesOf(path) {
  const parts = path.split("/");
  const fileDates = /\.(docx?|hwpx?)$/i.test(path) ? findDates(parts[parts.length - 1]).filter(d => d.hasDay) : [];
  const candidates = [...parts.slice(0, -1).reverse(), parts[parts.length - 1]];
  for (const seg of candidates) {
    const ds = findDates(seg);
    // Word collections often have a month or annual range outside a precise file date.
    // Preserve the existing explicit day-folder rule while avoiding a fabricated month-first day.
    if (ds.length && fileDates.length && (ds.length > 1 || !ds[0].hasDay)) return { start: fileDates[0].date, end: "", explicitEnd: false };
    if (ds.length) return { start: ds[0].date, end: ds.length > 1 ? ds[1].date : "", explicitEnd: ds.length > 1 };
  }
  return { start: "", end: "", explicitEnd: false };
}

// 상품명 추정: 파일명에서 확장자·문서유형·날짜·구분기호를 뺀 나머지
// 문서유형을 뜻하는 말 (긴 말부터 지워야 "보험약관"에서 "보험"만 남지 않음)
const DOC_WORDS = ["보험약관", "보통약관", "특별약관", "기본약관", "특약약관", ...DOC_TYPES];

function productNameOf(fileName) {
  let s = fileName.replace(/\.(pdf|docx?|hwpx?)$/i, "");
  // "[보험약관] (무)…", "【사업방법서】…" 같은 대괄호 머리표 제거 (상품명의 둥근 괄호 "(무)"는 유지)
  s = s.replace(/[\[【〔［][^\]】〕］]*[\]】〕］]/g, " ");
  // Internal Word files put revision labels after the document type. They are not product names.
  const typeAt = DOC_WORDS.map(t => s.indexOf(t)).filter(i => i > 0).sort((a, b) => a - b)[0];
  if (typeAt !== undefined && /[가-힣]{2}/.test(s.slice(0, typeAt))) s = s.slice(0, typeAt);
  for (const d of findDates(s).reverse()) s = s.slice(0, d.s) + " " + s.slice(d.e);
  for (const t of DOC_WORDS) s = s.split(t).join(" ");
  // "(계약자용)", "_계약자용" 등은 같은 상품으로 봄 → 상품명에서 제외
  s = s.replace(/[(（]\s*계약자\s*용\s*[)）]|계약자\s*용/g, " ");
  s = s.replace(/(보통|특별)\s*$/, "").replace(/[_\-\s~]+/g, " ").trim();
  return s;
}

// 같은 상품으로 묶는 키: 공백 무시, "무배당 ○○"과 "(무)○○"은 같은 상품
const productKeyFrom = name => norm(name).replace(/^무배당/, "(무)");

function dayBefore(iso) {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() - 1);
  return d.toLocaleDateString("sv-SE");
}

// 같은 상품(추정 상품명 동일)의 다음 판매일자 하루 전을 판매종료일로 추정
function inferEndDates() {
  const groups = {};
  DOCS.filter(d => d.start && !d.explicitEnd).forEach(d => (groups[d.productKey] ||= []).push(d));
  for (const list of Object.values(groups)) {
    const starts = [...new Set(list.map(d => d.start))].sort();
    list.forEach(d => {
      const next = starts.find(s => s > d.start);
      d.end = next ? dayBefore(next) : "";
    });
  }
}

// ---------- PDF 텍스트 추출 ----------
async function extractPages(data) {
  const pdf = await pdfjsLib.getDocument({ data, CMapReaderFactory: EmbeddedCMapReaderFactory, cMapPacked: true }).promise;
  const pages = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const tc = await page.getTextContent();
    // 글자 위치(y)가 바뀌면 줄바꿈 → 원문 줄 단위로 근거를 보여줄 수 있게 함
    let text = "", lastY = null;
    for (const it of tc.items) {
      const y = it.transform ? it.transform[5] : null;
      if (lastY !== null && y !== null && Math.abs(y - lastY) > 2 && !text.endsWith("\n")) text += "\n";
      text += it.str + (it.hasEOL ? "\n" : "");
      if (y !== null && it.str) lastY = y;
    }
    pages.push(text);
    page.cleanup();
  }
  await pdf.destroy();
  return pages;
}

// 파일명에 상품명이 없으면(코드·번호뿐) 바로 위 폴더명을 상품명으로 씀
// 예) 공시실 다운로드 도구 구조: 2026/2026.04.01/(무)OO보험/[보험약관] 원본파일명.pdf
function productNameFromPath(path) {
  const parts = path.split("/");
  const fromFile = productNameOf(parts[parts.length - 1]);
  if (/[가-힣]{2,}/.test(fromFile) || parts.length < 2) return fromFile;
  const folder = parts[parts.length - 2];
  return findDates(folder).length || !/[가-힣]{2,}/.test(folder) ? fromFile : productNameOf(folder);
}

function makeDoc(path, extra) {
  const name = path.split("/").pop();
  const productName = productNameFromPath(path);
  return { path, name, docType: docTypeOf(name), productName, productKey: productKeyFrom(productName),
           ...saleDatesOf(path), saleFolder: saleFolderOf(path), format: name.split(".").pop().toLowerCase(), textKind: /\.(docx|hwpx)$/i.test(name) ? "section" : "page", pages: [], error: "", ...extra };
}

async function readPages(doc, getBytes) {
  try {
    if (isLinkOnly(doc)) { doc.pages = []; doc.textKind = "link"; doc.error = ""; return; }
    if (isWord(doc)) {
      if (!SERVER_MODE) throw new Error("Word/한글 본문은 start-search.bat으로 실행한 PC 앱에서 읽습니다.");
      if (["docx", "hwpx"].includes(doc.format)) {
        const data = await api("api/read_document", { path: doc.path });
        doc.pages = data.pages;
        doc.textKind = data.text_kind;
      } else {
        const result = await api("api/preview", { path: doc.path });
        doc.previewUrl = result.url; doc.renderer = result.renderer;
        doc.pages = await extractPages(new Uint8Array(await (await fetch(result.url)).arrayBuffer()));
        doc.textKind = "page";
      }
    } else doc.pages = await extractPages(await getBytes());
    if (!doc.pages.join("").trim()) doc.error = "본문 텍스트 없음 (스캔 이미지 PDF일 수 있음)";
  } catch (e) {
    doc.error = "읽기 실패: " + (e && e.message ? e.message : e);
  }
}

// 판매중 → 판매중지로 바뀐 상품이 두 폴더에 모두 있으면(같은 상품·판매일자·문서유형) 판매중지 쪽만 남김
let movedDupCount = 0;
function dropMovedDuplicates() {
  const stopKeys = new Set(DOCS.filter(d => d.saleFolder === "stop").map(d => [d.productKey, d.start, d.docType].join("|")));
  const before = DOCS.length;
  for (let i = DOCS.length - 1; i >= 0; i--) {
    const d = DOCS[i];
    if (d.saleFolder === "on" && stopKeys.has([d.productKey, d.start, d.docType].join("|"))) DOCS.splice(i, 1);
  }
  movedDupCount += before - DOCS.length;
  return movedDupCount;
}

function finishLoading(label) {
  const dup = dropMovedDuplicates();
  if (dup) label += ` (판매중지로 옮겨진 중복 ${dup}개 제외)`;
  if (!SERVER_MODE) DOCS.forEach(d => { d.searchText = norm(d.path + " " + d.pages.join(" ")); });
  inferEndDates();
  $("docsBar").style.width = "100%";
  setTimeout(() => { $("docsProgress").hidden = true; }, 600);
  const failed = DOCS.filter(d => d.error).length, noDate = DOCS.filter(d => !d.start).length;
  $("docsDot").classList.toggle("ok", DOCS.length > 0);
  const wordCount = DOCS.filter(isWord).length;
  $("docsStatus").textContent = `${label} — ${wordCount ? `문서 ${DOCS.length}개 (Word·한글 ${wordCount}개)` : `PDF ${DOCS.length}개`}` +
    (failed ? ` (본문 못 읽음 ${failed}개)` : "") + (noDate ? ` · 판매일자 인식 못함 ${noDate}개` : "");
  renderAll();
}

function resetDocs() {
  movedDupCount = 0;
  if (typeof SPEC_CACHE !== "undefined") SPEC_CACHE.clear();
  DOCS.forEach(d => d.url && d.url.startsWith("blob:") && URL.revokeObjectURL(d.url));
  DOCS.length = 0;
}

const progress = (i, n, path) => {
  $("docsProgress").hidden = false;
  $("docsStatus").textContent = `읽는 중 ${i + 1}/${n} — ${path}`;
  $("docsBar").style.width = `${(i / n) * 100}%`;
};

// 방법 1) [폴더 선택] — 파일을 매번 다시 선택 (index.html을 더블클릭해서 연 경우)
async function loadFolder(fileList) {
  const files = [...fileList].filter(f => /\.(pdf|docx?|hwpx?)$/i.test(f.name) && !f.name.startsWith("~$"));
  resetDocs();
  if (!files.length) {
    $("docsStatus").textContent = "선택한 폴더에 지원하는 기초서류가 없습니다.";
    renderAll();
    return;
  }
  const root = (files[0].webkitRelativePath || files[0].name).split("/")[0];
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const doc = makeDoc(file.webkitRelativePath || file.name, { file });
    progress(i, files.length, doc.path);
    await readPages(doc, async () => new Uint8Array(await file.arrayBuffer()));
    DOCS.push(doc);
  }
  finishLoading(`연결됨: ${root}`);
}

// 방법 2) 자동 연결 — start.bat(serve.py)로 연 경우. 지정 폴더 목록을 받아 오고,
// 색인이 안 된 PDF만 브라우저가 읽어서 내 PC의 검색 색인(.docs-cache/index.db)에 저장
// 웹 데모(교육자료 링크 등 내 PC가 아닌 주소로 연 경우): 서버 없이 가상 샘플 PDF를 브라우저에서 바로 읽음
const DEMO_MODE = location.protocol.startsWith("http") && !/^(127\.0\.0\.1|localhost)$/.test(location.hostname);
const SERVER_MODE = location.protocol.startsWith("http") && !DEMO_MODE;

async function api(path, body) {
  const res = await fetch(path, body === undefined ? { cache: "no-store" }
    : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "HTTP " + res.status);
  return data;
}

// 서버 모드에서는 본문을 필요할 때만 가져옴 (상품 분석·AI 프롬프트용)
async function ensurePages(docs) {
  if (!SERVER_MODE) return;
  for (const d of docs) {
    if (d.pagesLoaded || !d.id) continue;
    d.pages = (await api(`api/pages?id=${d.id}`)).pages;
    d.pagesLoaded = true;
    d._lines = null;
    d._sections = null;
  }
}

let indexing = false;

async function loadFromServer() {
  if (indexing) return;
  const { root, folder, files } = await api("api/docs");
  resetDocs();
  $("docsFolder").textContent = folder;
  for (const f of files) {
    const url = "docs/" + f.path.split("/").map(encodeURIComponent).join("/");
    DOCS.push(makeDoc(f.path, { url, id: f.id, size: f.size, mtime: f.mtime, fingerprint: f.fingerprint, textKind: f.text_kind, indexed: f.indexed,
                                error: f.error || "", features: f.features || {} }));
  }
  const todo = DOCS.filter(d => !d.indexed);
  finishLoading(`자동 연결: ${root}`);
  if (!todo.length) return;
  // 새 파일·수정된 파일만 읽어서 색인 (중간에 창을 닫아도 다음에 이어서 진행)
  indexing = true;
  $("reloadDocsBtn").disabled = true;
  $("changeDocsFolderBtn").disabled = true;
  const t0 = Date.now();
  try {
    for (let i = 0; i < todo.length; i++) {
      const d = todo[i];
      progress(i, todo.length, d.path);
      if (i > 2) {
        const left = Math.round((Date.now() - t0) / i * (todo.length - i) / 60000);
        $("docsStatus").textContent += ` · 남은 시간 약 ${left}분`;
      }
      await readPages(d, async () => new Uint8Array(await (await fetch(d.url)).arrayBuffer()));
      const r = await saveDocIndex(d);
      Object.assign(d, { id: r.id, features: r.features, indexed: true, pages: [], pagesLoaded: false });
      if (i % 25 === 24) renderAll(); // 색인된 문서부터 바로 검색 가능
    }
  } finally {
    indexing = false;
    $("reloadDocsBtn").disabled = false;
    $("changeDocsFolderBtn").disabled = false;
  }
  finishLoading(`자동 연결: ${root} (새로 색인 ${todo.length}개)`);
}

if (SERVER_MODE) {
  $("serverMode").hidden = false;
  $("noFolder").hidden = true;
  $("reloadDocsBtn").hidden = false;
  $("changeDocsFolderBtn").hidden = false;
  $("folderPicker").hidden = true;
  $("docsNote").textContent = "start.bat으로 실행 중 — 지정 폴더를 자동으로 읽어 내 PC의 검색 색인(앱 폴더 .docs-cache)에 저장합니다. " +
    "다음 실행부터는 새로 추가·수정된 파일만 읽습니다. 외부로는 아무것도 전송되지 않습니다.";
  const run = () => loadFromServer().catch(err => {
    indexing = false;
    $("docsStatus").textContent = /fetch|network/i.test(err.message)
      ? "자동 연결 실패: 앱 프로그램(start.bat 검은 창)에 연결하지 못했습니다. 검은 창이 닫혔거나 오류로 멈췄는지 확인하고, start.bat을 다시 실행하세요."
      : "자동 연결 실패: " + err.message;
  });
  $("reloadDocsBtn").addEventListener("click", run);
  $("changeDocsFolderBtn").addEventListener("click", async () => {
    const folder = window.prompt("연결할 Word·PDF 원본 폴더 경로를 입력하세요.", $("docsFolder").textContent);
    if (!folder || !folder.trim()) return;
    try { await api("api/set_folder", { folder }); await run(); }
    catch (err) { $("docsStatus").textContent = "폴더 변경 실패: " + err.message; }
  });
  run();
}

// 방법 3) 웹 데모 — 앱과 함께 올린 가상 샘플(sample-기초서류폴더)을 읽음. 외부로 보내는 것은 없음
async function loadDemo() {
  const list = window.SAMPLE_FILES || [];
  resetDocs();
  for (let i = 0; i < list.length; i++) {
    const url = list[i].split("/").map(encodeURIComponent).join("/");
    const doc = makeDoc(list[i], { url });
    progress(i, list.length, doc.path);
    await readPages(doc, async () => {
      const res = await fetch(url);
      if (!res.ok) throw new Error("HTTP " + res.status);
      return new Uint8Array(await res.arrayBuffer());
    });
    DOCS.push(doc);
  }
  finishLoading("웹 데모: 가상 샘플(가나다생명)");
}

if (DEMO_MODE) {
  $("noFolder").textContent = "가상 샘플 (웹 데모)";
  $("docsNote").textContent = "웹 데모 — 교육용 가상 샘플 PDF를 브라우저에서 바로 읽습니다. 내 PC의 기초서류 폴더 연결은 start.bat으로 실행한 앱에서 합니다.";
  loadDemo().catch(err => { $("docsStatus").textContent = "샘플 읽기 실패: " + err.message; });
}

// ---------- 검색 ----------
// 판매기간·분류·판매상태 조건 (키워드 검색과 질문 검색이 함께 사용)
const MAIN_DOC_TYPES = ["사업방법서", "상품요약서", "약관"];
function docMatchesFilters(d, { from, to, category, status, docType }) {
  if (isLinkOnly(d)) return false; // Product links only: never use these contents as search/analysis evidence.
  if (docType && (docType === "기타" ? MAIN_DOC_TYPES.includes(d.docType) : d.docType !== docType)) return false;
  // 판매기간 겹침: 판매개시일 <= To AND (종료일 빈값 OR 종료일 >= From). 판매일자를 모르면 기간 검색에서 제외
  if ((from || to) && !(d.start && (!to || d.start <= to) && (!from || !d.end || d.end >= from))) return false;
  if (category && !d.path.includes(category)) return false;
  if (status && docSaleStatus(d) !== status) return false;
  return true;
}

// 공백 제거 문자열에서 찾은 위치를 원문 위치로 되돌려 앞뒤 문맥을 잘라냄
function snippets(pageText, terms, max) {
  const map = [];
  let compact = "";
  for (let i = 0; i < pageText.length; i++) {
    if (!/\s/.test(pageText[i])) { compact += pageText[i].toLowerCase(); map.push(i); }
  }
  const out = [];
  for (const t of terms) { // 페이지당 단어별 첫 위치만
    const idx = compact.indexOf(t);
    if (out.length >= max || idx === -1) continue;
    const s = map[idx], e = map[idx + t.length - 1] + 1;
    const a = Math.max(0, s - 40), b = Math.min(pageText.length, e + 40);
    out.push({ before: pageText.slice(a, s), hit: pageText.slice(s, e), after: pageText.slice(e, b), lead: a > 0, tail: b < pageText.length });
  }
  return out;
}

const sortDocs = (rows) => rows
  // 정렬: 파일명(상품명) 일치 우선 → 판매개시일 최신순
  .sort((a, b) => (b.nameHit - a.nameHit) || (b.doc.start || "").localeCompare(a.doc.start || ""));

async function searchDocs(q) {
  const terms = q.keyword.trim().split(/\s+/).map(norm).filter(Boolean);
  let docs = DOCS.filter(d => docMatchesFilters(d, q));
  if (terms.length) {
    if (SERVER_MODE) {
      const ids = new Set((await api("api/search", { terms })).ids);
      docs = docs.filter(d => ids.has(d.id));
    } else {
      docs = docs.filter(d => terms.every(t => d.searchText.includes(t)));
    }
  }
  return sortDocs(docs.map(d => ({ doc: d, terms, nameHit: terms.length > 0 && terms.every(t => norm(d.name).includes(t)) })));
}

// 일치 문장: 파일 모드는 메모리 본문에서, 서버 모드는 색인에서 (화면에 보이는 문서만)
async function snippetsFor(docs, terms) {
  const out = new Map();
  if (!terms.length) return out;
  if (SERVER_MODE) {
    const ids = docs.filter(d => d.id).map(d => d.id);
    const res = ids.length ? (await api("api/snippets", { ids, terms })).snippets : {};
    docs.forEach(d => out.set(d, res[d.id] || []));
  } else {
    docs.forEach(d => {
      const list = [];
      d.pages.forEach((text, pi) => {
        if (list.length >= 3) return;
        snippets(text, terms, 3 - list.length).forEach(s => list.push({ ...s, page: pi + 1 }));
      });
      out.set(d, list);
    });
  }
  return out;
}

let docsRenderSeq = 0;
let docsPage = 1;
const docsPageSize = () => +$("docsPageSize").value || 20;

// keepPage: 쪽 이동·한 페이지 건수 변경일 때 true (새 검색이면 1쪽부터)
async function renderDocs(keepPage = false) {
  const seq = ++docsRenderSeq; // 빠르게 다시 검색하면 이전 결과는 버림
  if (!keepPage) docsPage = 1;
  const cur = currentQuery();
  // 질문(특징·문장) 검색일 때는 문서 목록 대신 '상품별 답변' 패널을 보여줌
  // 검색어·조건이 하나도 없으면 문서 목록 대신 상품 목록이 메인
  const f = cur.form, idle = !f.keyword.trim() && !f.from && !f.to && !f.category && !f.status && !f.docType;
  if (!DOCS.length || cur.mode !== "keyword" || idle) { $("docsPanel").hidden = true; return; }
  $("docsPanel").hidden = false;
  let rows, snips, pageRows;
  const size = docsPageSize();
  try {
    rows = await searchDocs(cur.form);
    const pages = Math.max(1, Math.ceil(rows.length / size));
    docsPage = Math.min(Math.max(1, docsPage), pages);
    pageRows = rows.slice((docsPage - 1) * size, docsPage * size);
    // 일치 문장은 지금 쪽에 보이는 문서만 가져옴
    snips = await snippetsFor(pageRows.map(r => r.doc), rows.length ? rows[0].terms : []);
  } catch (e) {
    if (seq === docsRenderSeq) $("docsSummary").textContent = "검색 실패: " + e.message;
    return;
  }
  if (seq !== docsRenderSeq) return;
  const notIndexed = DOCS.filter(d => SERVER_MODE && !d.indexed).length;
  const from = rows.length ? (docsPage - 1) * size + 1 : 0, to = (docsPage - 1) * size + pageRows.length;
  $("docsSummary").innerHTML = `검색 결과 <b>${rows.length}</b>건 / 불러온 PDF ${DOCS.length}건` +
    (rows.length > size ? ` · ${from}~${to}번째 표시` : "") +
    (notIndexed && cur.form.keyword.trim() ? ` · 색인 중인 ${notIndexed}건은 아직 검색되지 않음` : "");
  renderPager(rows.length, size);
  if (!rows.length) {
    $("docsResults").innerHTML = `<tr><td colspan="5" class="empty">조건에 맞는 문서가 없습니다.</td></tr>`;
    return;
  }
  $("docsResults").innerHTML = pageRows.map(({ doc: d, terms }) => {
    let snipHtml = "", firstPage = 1, anchor = "";
    if (terms.length) {
      const list = snips.get(d) || [];
      if (list.length) { firstPage = list[0].page; anchor = list[0].before + list[0].hit + list[0].after; }
      snipHtml = list.map(s => `<p class="snip"><span class="pg">${docLoc(d, s.page)}</span>${s.lead ? "…" : ""}${esc(s.before)}<mark>${esc(s.hit)}</mark>${esc(s.after)}${s.tail ? "…" : ""}</p>`).join("")
        || `<p class="snip note">파일 경로에서 일치</p>`;
    }
    if (d.error) snipHtml += `<p class="warn">${esc(d.error)}</p>`;
    const period = d.start ? `${esc(d.start)}<div class="path">~ ${esc(d.end || "")}${d.end && !d.explicitEnd ? " (추정)" : ""}</div>` : `<span class="warn">인식 못함</span>`;
    return `<tr>
      <td>${period}</td>
      <td>${esc(d.docType)}</td>
      <td>${esc(d.productName || d.name)}<div class="path">${esc(d.path)}</div></td>
      <td>${snipHtml}</td>
      <td class="actions"><button type="button" ${refAttrs(d, firstPage, anchor)}>열기</button>
        <button type="button" data-analyze="${esc(productKeyOf(d))}" data-start="${esc(d.start)}">분석</button></td>
    </tr>`;
  }).join("");
}

// 쪽 번호: « ‹ 1 2 3 … › » (현재 쪽 앞뒤로 최대 10개)
function renderPager(total, size) {
  const pages = Math.ceil(total / size);
  if (pages <= 1) { $("docsPager").innerHTML = ""; return; }
  const startP = Math.max(1, Math.min(docsPage - 4, pages - 9)), endP = Math.min(pages, startP + 9);
  const btn = (p, label, title) => `<button type="button" data-docs-page="${p}"${p === docsPage && label === String(p) ? ' class="on" aria-current="page"' : ""}${p < 1 || p > pages ? " disabled" : ""} title="${title || p + "쪽"}">${label}</button>`;
  let html = btn(1, "«", "처음") + btn(docsPage - 1, "‹", "이전 쪽");
  for (let p = startP; p <= endP; p++) html += btn(p, String(p));
  html += btn(docsPage + 1, "›", "다음 쪽") + btn(pages, "»", "마지막") + `<span class="pinfo">${docsPage} / ${pages}쪽</span>`;
  $("docsPager").innerHTML = html;
}
$("docsPager").addEventListener("click", e => {
  const b = e.target.closest("button[data-docs-page]");
  if (!b || b.disabled) return;
  docsPage = +b.dataset.docsPage;
  renderDocs(true).then(() => $("docsPanel").scrollIntoView({ block: "start" }));
});
$("docsPageSize").addEventListener("change", () => { docsPage = 1; renderDocs(true); });

// 상품·판매일자의 기초서류 원문 링크 (사업방법서 / 상품요약서 / 약관 순, 같은 유형이 여럿이면 번호)
function docLinksHtml(docs, cls = "doclinks") {
  const parts = [];
  for (const t of MAIN_DOC_TYPES) {
    const list = docs.filter(d => d.docType === t);
    if (!list.length) { parts.push(`<span class="miss">${t} 없음</span>`); continue; }
    parts.push(list.map((d, i) => `<a href="#" ${refAttrs(d, 1)} title="${esc(d.path)}">${t}${list.length > 1 ? ` (${i + 1})` : ""}</a>`).join(" "));
  }
  for (const t of LINK_DOC_TYPES) {
    const list = docs.filter(d => d.docType === t);
    parts.push(list.length ? list.map((d, i) => `<a href="#" data-original="${DOCS.indexOf(d)}" title="원본을 PC 연결 프로그램으로 열기: ${esc(d.path)}">${t}${list.length > 1 ? ` (${i + 1})` : ""} ↗</a>`).join(" ") : `<span class="miss">${t} 없음</span>`);
  }
  docs.filter(d => !MAIN_DOC_TYPES.includes(d.docType) && !isLinkOnly(d))
    .forEach(d => parts.push(`<a href="#" ${refAttrs(d, 1)} title="${esc(d.path)}">${esc(d.docType === "기타" ? d.name : d.docType)}</a>`));
  return `<span class="${cls}">${parts.join("")}</span>`;
}

// 같은 상품으로 묶는 키 (파일명에서 상품명을 못 뽑으면 파일명 전체)
const productKeyOf = d => d.productKey || norm(d.name);

// PDF 열기: 메모리의 파일을 새 탭으로 (일치한 페이지로 이동). 결과·답변·분석 화면 공통
async function openDoc(index, page, unit = "page", anchor = "") {
  const d = DOCS[index];
  if (!d) return;
  if (isLinkOnly(d)) return openOriginal(d);
  if (isWord(d)) {
    $("modalTitle").textContent = `${d.productName || d.name} · ${d.docType} 미리보기`;
    $("modalBody").style.gridTemplateColumns = "minmax(300px, 1fr)";
    $("modalBody").innerHTML = `<p class="note">Word 원문 미리보기를 준비하는 중입니다. 처음에는 문서 프로그램으로 변환하므로 시간이 걸릴 수 있습니다.</p>`;
    $("imgModal").hidden = false;
    try {
      await ensurePages([d]);
      const nativeText = unit === "section" ? anchor || (d.nativePages || d.pages)[(+page || 1) - 1] || "" : "";
      await ensureWordPreview(d);
      if (nativeText) {
        const candidates = nativeText.split("\n").map(t => norm(t).replace(/\|/g, "")).filter(s => s.length >= 15).slice(0, 30);
        let found = -1, multiple = false;
        for (const candidate of candidates) {
          for (const length of [80, 40, 24]) {
            const key = candidate.slice(0, length), hits = d.pages.map((p, i) => norm(p).includes(key) ? i : -1).filter(i => i >= 0);
            if (hits.length) { found = hits[0]; multiple = hits.length > 1; break; }
          }
          if (found >= 0) break;
        }
        page = found >= 0 ? found + 1 : 1;
        d.locationNotice = found >= 0 ? multiple ? "같은 근거 문구가 여러 쪽에 있어 첫 일치 쪽을 엽니다." : "근거 문구를 변환된 PDF 쪽으로 연결했습니다." : "해당 구간의 실제 쪽을 확정하지 못해 첫 쪽을 엽니다. 원문에서 확인해 주세요.";
      }
      return showDocPage(d, +page || 1);
    } catch (err) {
      $("modalBody").innerHTML = `<div><p class="warn">미리보기를 만들지 못했습니다: ${esc(err.message)}</p><button type="button" data-original="${DOCS.indexOf(d)}">원본 ${d.format.toUpperCase()} 열기</button><p class="note">DOCX 본문 검색은 문서 변환 없이 사용할 수 있습니다.</p></div>`;
      return;
    }
  }
  if (DEMO_MODE) { showDocPage(d, +page || 1); return; } // 웹 데모는 새 창을 못 열어 화면 안에 그 쪽을 그림으로 보여 줌
  d.url ||= URL.createObjectURL(d.file); // 서버 모드는 처음부터 docs/... 주소가 있음
  window.open(`${d.url}#page=${page || 1}`, "_blank");
}
document.addEventListener("click", e => {
  const original = e.target.closest("[data-original]");
  if (original) { e.preventDefault(); openOriginal(DOCS[+original.dataset.original]).catch(err => demoNotice(err.message)); return; }
  const btn = e.target.closest("button[data-open], a[data-open]");
  if (!btn) return;
  e.preventDefault();
  openDoc(+btn.dataset.open, btn.dataset.page, btn.dataset.unit, btn.dataset.anchor || "");
});

async function openOriginal(d) {
  if (SERVER_MODE) {
    const result = await api("api/open_original", { path: d.path });
    if (result.opened) return;
  }
  d.url ||= URL.createObjectURL(d.file);
  const a = document.createElement("a"); a.href = d.url; a.download = d.name; a.click();
}

const saveDocIndex = d => api("api/index", { path: d.path, size: d.size, mtime: d.mtime, fingerprint: d.fingerprint || "", reader_version: isWord(d) ? "office-text-1" : "", text_kind: d.textKind, pages: d.pages, error: d.error });

async function ensureWordPreview(d) {
  if (!isWord(d) || isLinkOnly(d)) return;
  if (d.previewUrl && d.textKind === "page") return;
  if (d.previewTask) return d.previewTask;
  d.previewTask = (async () => {
    await ensurePages([d]);
    const result = await api("api/preview", { path: d.path });
    if (result.fingerprint !== d.fingerprint) throw new Error("원본이 변경됐습니다. 기초서류 새로고침 후 다시 열어 주세요.");
    const pages = await extractPages(new Uint8Array(await (await fetch(result.url)).arrayBuffer()));
    const saved = await saveDocIndex({ ...d, pages, textKind: "page", error: "" });
    d.nativePages ||= d.textKind === "section" ? d.pages : [];
    Object.assign(d, { pages, pagesLoaded: true, textKind: "page", previewUrl: result.url, renderer: result.renderer, error: "", id: saved.id, features: saved.features });
    for (const key of ["_lines", "_sections", "_tableSegs", "_sectionImgs"]) delete d[key];
    if (typeof SPEC_CACHE !== "undefined") SPEC_CACHE.clear();
    if (typeof CATALOG !== "undefined") CATALOG = buildCatalog();
  })();
  try { await d.previewTask; } finally { d.previewTask = null; }
}

async function prepareWordPreviews(docs) {
  for (const d of docs.filter(x => isWord(x) && !isLinkOnly(x) && !x.error)) {
    try { await ensureWordPreview(d); d.previewError = ""; }
    catch (err) { d.previewError = err.message; }
  }
}

$("folderInput").addEventListener("change", e => {
  loadFolder(e.target.files).catch(err => { $("docsStatus").textContent = "폴더 읽기 실패: " + err.message; });
  e.target.value = "";
});
