@echo off
chcp 65001 >nul
cd /d "%~dp0product-search"
python serve.py --sample
pause
